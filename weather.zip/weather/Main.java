public class Main{
    public static void main(String args[]){
    
	WeatherStationList wsl = new WeatherStationList();
	wsl.input();

	}
}